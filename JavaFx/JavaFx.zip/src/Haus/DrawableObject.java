package Haus;

import javafx.scene.image.Image;

public class DrawableObject {
	
	public String name;
	public Image image;
	public double x, y;
	
	public DrawableObject(Object obj) {
		name = obj.toString();
		image = new Image("/img/HAUSIcon.png");
		x = 100;
		y = 100;
	}
	
	/*
	public static void node(Object obj)
	{
		
		
	}
	*/
}
